let employeeData = [
  { id: 1, name: "Fatima Beatriz", email: "Fatima Beatriz@gmail.com", phone: "0985674321", position: "Staff" },
  { id: 2, name: "Gabriel Hanna", email: "Gabriel Hanna@gmail.com", phone: "0353674231", position: "Staff" },
  { id: 3, name: "Charles Diya", email: "Charles Diya@gmail.com", phone: "0347658833", position: "Staff" },
  { id: 4, name: "Frank Lamdo", email: "Frank Lamdo@gmail.com", phone: "0975444768", position: "Manager" },
  { id: 5, name: "Louis Tom", email: "Louis Tom@gmail.com", phone: "0789568223", position: "Staff" },
];

function renderTable() {
  const tbody = document.getElementById("employeeTable");
  tbody.innerHTML = "";
  employeeData.forEach(emp => {
    const row = `
      <tr>
        <td>${emp.id}</td>
        <td>${emp.name}</td>
        <td>${emp.email}</td>
        <td>${emp.phone}</td>
        <td>${emp.position}</td>
        <td>
          <button class="edit">Edit</button>
          <button class="delete" onclick="deleteEmployee(${emp.id})">Delete</button>
        </td>
      </tr>
    `;
    tbody.innerHTML += row;
  });
}

function openModal() {
  document.getElementById("modal").style.display = "block";
}

function closeModal() {
  document.getElementById("modal").style.display = "none";
  document.getElementById("employeeForm").reset();
}

function deleteEmployee(id) {
  employeeData = employeeData.filter(emp => emp.id !== id);
  renderTable();
}

document.getElementById("employeeForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const phone = document.getElementById("phone").value;
  const position = document.getElementById("position").value;
  const gender = document.querySelector('input[name="gender"]:checked')?.value;

  const newEmp = {
    id: employeeData.length + 1,
    name, email, phone, position
  };

  employeeData.push(newEmp);
  renderTable();
  closeModal();
});

renderTable();
